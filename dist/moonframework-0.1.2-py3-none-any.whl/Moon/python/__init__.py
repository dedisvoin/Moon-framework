from colorama import Fore
print(f"Welcome to: <{Fore.BLUE}Moon{Fore.RESET}> by {Fore.LIGHTMAGENTA_EX}Pavlov Ivan{Fore.RESET}.")