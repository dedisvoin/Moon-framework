from colorama import Fore

__version__ = '0.1.3'

print(f"Welcome to: <{Fore.BLUE}Moon{Fore.RESET} {__version__}> by {Fore.LIGHTMAGENTA_EX}Pavlov Ivan{Fore.RESET}.")